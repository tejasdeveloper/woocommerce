<?PHP 
/* 
Plugin Name: Custom Filter by Tejas
Plugin URI: hikebranding.com
Description: Custom filter for woocommerce products
Version: 1
Author: Tejas
Author URI: hikebranding.com
License: GPLv2 or later
*/	

	include "backend.php";
	
	include "frontend.php";
	
	include "script-include.php";

?>